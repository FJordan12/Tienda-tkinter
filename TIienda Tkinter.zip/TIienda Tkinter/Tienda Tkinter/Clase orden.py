class Orden:
    def __init__(self, cliente):
        self.cliente = cliente
        self.items = []
        self.total = 0

    def agregar_item(self, item):
        self.items.append(item)
        self.calcular_total()

    def calcular_total(self):
        self.total = sum(item.calcular_subtotal() for item in self.items)

    def mostrar_info(self):
        print(f"Orden de: {self.cliente.nombre} {self.cliente.apellido}")
        for item in self.items:
            item.mostrar_info()
        print(f"Total de la Orden: {self.total}")