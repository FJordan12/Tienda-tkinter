class ItemOrden:
    def __init__(self, producto, cantidad):
        self.producto = producto
        self.cantidad = cantidad

    def calcular_subtotal(self):
        return self.cantidad * self.producto.precio

    def mostrar_info(self):
        print(f"Producto: {self.producto.nombre} | Cantidad: {self.cantidad} | Subtotal: {self.calcular_subtotal()}")
