def main():
    tienda = ()  
    while True:
        print("\nBienvenido a QualityShop")
        print("1. Registrar un nuevo cliente")
        print("2. Crear una nueva orden")
        print("3. Mostrar listado de productos")
        print("4. Salir")

        opcion = input("Ingrese el número de la opción que desee: ")

        if opcion == "1":
            nombre = input("Ingrese el nombre del cliente: ")
            apellido = input("Ingrese el apellido del cliente: ")
            id_cliente = input("Ingrese el ID del cliente: ")
            cliente = cliente(nombre, apellido, id_cliente)
            tienda.registrar_cliente(cliente)
            print("Cliente registrado con éxito.")

        elif opcion == "2":
            if not tienda.productos:
                print("No hay productos registrados en la tienda.")
                continue

            if not tienda.clientes:
                print("No hay clientes registrados en la tienda.")
                continue

            print("Listado de Clientes:")
            for i, cliente in enumerate(tienda.clientes, start=1):
                print(f"{i}. {cliente.nombre} {cliente.apellido}")

            cliente_index = int(input("Seleccione el número del cliente que realizará la orden: ")) - 1
            cliente_seleccionado = tienda.clientes[cliente_index]

            orden = tienda.crear_orden(cliente_seleccionado)
            print("Orden creada con éxito.")

            while True:
                print("Listado de Productos:")
                for i, producto in enumerate(tienda.productos, start=1):
                    print(f"{i}. {producto.nombre} - {producto.precio} ({producto.categoria.nombre})")

                producto_index = int(input("Seleccione el número del producto que desea agregar: ")) - 1
                producto_seleccionado = tienda.productos[producto_index]
                cantidad = int(input("Ingrese la cantidad: "))
                item_orden = item_orden(producto_seleccionado, cantidad)
                orden.agregar_item(item_orden)
                print("Producto agregado con éxito.")

                continuar = input("¿Desea agregar algo más? (s/n): ")
                if continuar.lower() != 's':
                    break

            print("Orden finalizada.")
            orden.mostrar_info()

        elif opcion == "3":
            if not tienda.productos:
                print("No hay productos registrados en la tienda.")
                continue

            tienda.mostrar_productos()

        elif opcion == "4":
            print("¡Gracias por preferirnos!")
            break

        else:
            print("Opción no válida. Por favor, seleccione una opción válida.")

if __name__ == "__main__":
    main()