class Tienda:
    def __init__(self):
        self.productos = []
        self.clientes = []
        self.ordenes = []
        self.categorias = []

        categoria1 = categoria1("Electródomesticos")
        categoria2 = categoria1("Ropa")
        categoria3 = categoria1("accesorios")

        self.categorias.extend([categoria1, categoria2, categoria3])

        producto1 = producto1("Televisor", 900.000, categoria1)
        producto2 = producto2("ventilador", 800.00, categoria1)
        producto3 = producto3("Camiseta", 20.000, categoria2)
        producto4 = producto4("Jeans", 40.000, categoria2)
        producto5 = producto5("manillas", 20.000, categoria3)
        producto6 = producto6("aretes", 15.000, categoria3)

        self.productos.extend([producto1, producto2, producto3, producto4, producto5, producto6])

    def registrar_cliente(self, cliente):
        self.clientes.append(cliente)

    def crear_orden(self, cliente):
        orden = orden(cliente)
        self.ordenes.append(orden)
        return orden

    def mostrar_productos(self):
        print("Listado de Productos:")
        for producto in self.productos:
            producto.mostrar_info()