import tkinter as tk
from PIL import Image, ImageTk
from tkinter import messagebox

class Tienda:
    def __init__(self):
        self.clientes = []
        self.productos = []

    def registrar_cliente(self, cliente):
        self.clientes.append(cliente)

    def crear_orden(self, cliente):
        return Orden(cliente)

    def mostrar_productos(self):
        productos_text = "\n".join([f"{producto.nombre} - {producto.precio} ({producto.categoria})" for producto in self.productos])
        messagebox.showinfo("Listado de Productos", productos_text)

class Cliente:
    def __init__(self, nombre, apellido, id_cliente):
        self.nombre = nombre
        self.apellido = apellido
        self.id_cliente = id_cliente

class Producto:
    def __init__(self, nombre, precio, categoria):
        self.nombre = nombre
        self.precio = precio
        self.categoria = categoria

class Orden:
    def __init__(self, cliente):
        self.cliente = cliente
        self.items = []

    def agregar_item(self, item):
        self.items.append(item)

    def calcular_total(self):
        total = sum(item.producto.precio * item.cantidad for item in self.items)
        return total

class ItemOrden:
    def __init__(self, producto, cantidad):
        self.producto = producto
        self.cantidad = cantidad

def registrar_cliente():
    nombre = entry_nombre.get()
    apellido = entry_apellido.get()
    id_cliente = entry_id_cliente.get()
    cliente = Cliente(nombre, apellido, id_cliente)
    tienda.registrar_cliente(cliente)
    messagebox.showinfo("Cliente registrado", "Cliente registrado satisfactoriamente.")

def crear_orden():
    if not tienda.clientes:
        messagebox.showwarning("No hay clientes", "No hay clientes registrados.")
        return

    ventana = tk.Toplevel()
    ventana.title("Crear Orden")
    ventana.configure(bg="violet")

    label_cliente = tk.Label(ventana, text="Seleccionar Cliente:", bg="violet")
    label_cliente.grid(row=0, column=0, padx=5, pady=5)

    clientes_listbox = tk.Listbox(ventana, height=10, width=50)
    clientes_listbox.grid(row=0, column=1, padx=5, pady=5)

    for cliente in tienda.clientes:
        clientes_listbox.insert(tk.END, f"{cliente.nombre} {cliente.apellido}")

    button_seleccionar = tk.Button(ventana, text="Seleccionar Cliente", command=lambda: seleccionar_cliente(ventana, clientes_listbox), bg="violet", fg="white")
    button_seleccionar.grid(row=1, column=0, columnspan=2, pady=10)

def seleccionar_cliente(ventana, clientes_listbox):
    cliente_index = clientes_listbox.curselection()
    if cliente_index:
        cliente_seleccionado = tienda.clientes[cliente_index[0]]
        orden = tienda.crear_orden(cliente_seleccionado)
        ventana_orden(orden)
        ventana.destroy()
    else:
        messagebox.showwarning("Cliente no seleccionado", "Por favor, seleccione un cliente para continuar.")

def ventana_orden(orden):
    ventana = tk.Toplevel()
    ventana.title("Crear Orden")
    ventana.configure(bg="Red")

    label_producto = tk.Label(ventana, text="Producto:", bg="Red")
    label_producto.grid(row=0, column=0, padx=5, pady=5)

    productos_listbox = tk.Listbox(ventana, height=10, width=50, selectmode=tk.MULTIPLE)
    productos_listbox.grid(row=0, column=1, padx=5, pady=5)

    for producto in tienda.productos:
        productos_listbox.insert(tk.END, f"{producto.nombre} - {producto.precio} ({producto.categoria})")

    label_cantidad = tk.Label(ventana, text="Cantidad:", bg="Red")
    label_cantidad.grid(row=1, column=0, padx=5, pady=5)

    entry_cantidad = tk.Entry(ventana)
    entry_cantidad.grid(row=1, column=1, padx=5, pady=5)

    button_agregar = tk.Button(ventana, text="Agregar Producto", command=lambda: agregar_producto(orden, productos_listbox, entry_cantidad), bg="violet", fg="white")
    button_agregar.grid(row=2, column=0, columnspan=2, pady=10)

    button_finalizar = tk.Button(ventana, text="Finalizar Orden", command=lambda: finalizar_orden(orden, ventana), bg="Red", fg="white")
    button_finalizar.grid(row=3, column=0, columnspan=2, pady=10)

def agregar_producto(orden, productos_listbox, entry_cantidad):
    productos_seleccionados = productos_listbox.curselection()
    if productos_seleccionados:
        for producto_index in productos_seleccionados:
            producto_seleccionado = tienda.productos[producto_index]
            cantidad = entry_cantidad.get()
            if cantidad.isdigit():
                item_orden = ItemOrden(producto_seleccionado, int(cantidad))
                orden.agregar_item(item_orden)
                entry_cantidad.delete(0, tk.END)
            else:
                messagebox.showwarning("Cantidad inválida", "Por favor, ingrese una cantidad válida.")
    else:
        messagebox.showwarning("Producto no seleccionado", "Por favor, seleccione al menos un producto.")

def finalizar_orden(orden, ventana):
    total = orden.calcular_total()
    mensaje = f"Tienda: Tienda QualityShop\n"
    mensaje += f"Cliente: {orden.cliente.nombre} {orden.cliente.apellido} - ID: {orden.cliente.id_cliente}\n"
    mensaje += f"Productos:\n"
    for item in orden.items:
        mensaje += f"{item.producto.nombre} - Precio: ${item.producto.precio} - Cantidad: {item.cantidad}\n"
    mensaje += f"\nTotal: ${total}"
    messagebox.showinfo("Factura", mensaje)
    ventana.destroy()

def mostrar_productos():
    tienda.mostrar_productos()

tienda = Tienda()


tienda.productos = [
    Producto("Camisa", 50, "Ropa"),
    Producto("Pantalón", 80, "Ropa"),
    Producto("Zapatos", 120, "Calzado"),
    Producto("Buzos", 150, "Papelería"),
    Producto("Medias", 5, "Papelería")
]

tienda.clientes = [
    Cliente("Juan", "Cardenas", "79268410"),
    Cliente("Cristian", "Torrado", "9082473"),
    Cliente("Camilo", "Mejia", "10384620")
]

root = tk.Tk()
root.title("Tienda QualityShop")
root.configure(bg="Green")

frame = tk.Frame(root, bg="Green")
frame.pack(padx=20, pady=20)

imagen = Image.open(r"C:\Users\cataf\Downloads\TIENDAV..png") 
imagen = imagen.resize((200, 200))
imagen_tk = ImageTk.PhotoImage(imagen)

label_imagen = tk.Label(frame, image=imagen_tk, bg="Green")
label_imagen.grid(row=0, column=0, columnspan=2, padx=10, pady=10)

label_nombre = tk.Label(frame, text="Nombre:", bg="Green")
label_nombre.grid(row=1, column=0, padx=5, pady=5)

entry_nombre = tk.Entry(frame)
entry_nombre.grid(row=1, column=1, padx=5, pady=5)

label_apellido = tk.Label(frame, text="Apellido:", bg="Green")
label_apellido.grid(row=2, column=0, padx=5, pady=5)

entry_apellido = tk.Entry(frame)
entry_apellido.grid(row=2, column=1, padx=5, pady=5)

label_id_cliente = tk.Label(frame, text="ID Cliente:", bg="Green")
label_id_cliente.grid(row=3, column=0, padx=5, pady=5)

entry_id_cliente = tk.Entry(frame)
entry_id_cliente.grid(row=3, column=1, padx=5, pady=5)

button_registrar_cliente = tk.Button(frame, text="Registrar Cliente", command=registrar_cliente, bg="White", fg="Black")
button_registrar_cliente.grid(row=4, column=0, columnspan=2, pady=10)

button_mostrar_productos = tk.Button(frame, text="Mostrar Productos", command=mostrar_productos, bg="White", fg="Black")
button_mostrar_productos.grid(row=5, column=0, columnspan=2, pady=10)

button_crear_orden = tk.Button(frame, text="Crear Orden", command=crear_orden, bg="White", fg="Black")
button_crear_orden.grid(row=6, column=0, columnspan=2, pady=10)

root.mainloop()
