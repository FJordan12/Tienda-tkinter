class Producto:
    def __init__(self, nombre, precio, categoria):
        self.nombre = nombre
        self.precio = precio
        self.categoria = categoria

    def mostrar_info(self):
        print(f"Producto: {self.nombre}")
        print(f"Precio: {self.precio}")
        print(f"Categoría: {self.categoria.nombre}")